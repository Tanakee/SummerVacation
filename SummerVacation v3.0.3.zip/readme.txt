※テクスチャパックの取り扱いについて

使用は-PR民のなつやすみ-内限定
二次配布禁止
改変＆転載一切禁止
（使用は元サイト様からお願い致します）

音源をお借りした方々

効果音ラボ様
 https://soundeffect-lab.info/

VSQ plus+様
 https://vsq.co.jp/plus/